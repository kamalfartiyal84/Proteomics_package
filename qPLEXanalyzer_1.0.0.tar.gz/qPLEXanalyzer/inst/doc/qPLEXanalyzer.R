## ----options,echo=FALSE-----------------------------------------------
options(width=72)

## ----libs, message=FALSE, cache=TRUE, warning= FALSE------------------
library(qPLEXanalyzer)
data(human_anno)
data(exp2_Xlink)

## ----Import,fig.width=6,fig.height=5,out.width='.85\\textwidth',message=FALSE,cache=TRUE----
MSnset_data <- convertToMSnset(exp2_Xlink$intensities,
                               metadata=exp2_Xlink$metadata,
                               indExpData=c(7:16),indFData=c(1:6))

## ----Filter,fig.width=6,fig.height=5,out.width='.85\\textwidth', fig.cap="Density plots of raw intensities for TMT-10plex experiment.", message=FALSE,cache=TRUE,fig.asp=0.7----
sampleColours <- assignColours(MSnset_data, groupColourSchemes = 
                                 c("Blues","Reds","Greens"))
print(intensityPlot(MSnset_data, sampleColours, title = "Peptide intensity distribution"))

## ----Corrplot,fig.width=7,fig.height=7,out.width='.85\\textwidth', fig.cap="Correlation plot of peptide intensitites", message=FALSE,cache=TRUE----
MSnset_data <- MSnset_data[,c(1:4,6:9,5,10)]
corrPlot(MSnset_data,method="shade")

## ----hierarchicalplot,fig.width=6,fig.height=5,out.width='0.85\\textwidth', fig.cap="Clustering plot of peptide intensitites", message=FALSE,cache=TRUE,fig.asp=0.7----
exprs(MSnset_data) <- exprs(MSnset_data)+0.01
label_color <- c(rep("red",4),rep("darkgreen",4),rep("orange",2))
hierarchicalPlot(MSnset_data,label_color,branchlength=95,title="Clustering plot")

## ----pcaplot,fig.width=6,fig.height=5,out.width='.85\\textwidth', fig.cap="PCA plot of peptide intensitites", message=FALSE,cache=TRUE,fig.asp=0.7----
grpcolor <- c("darkgreen","red","orange")
pcaPlot(MSnset_data, groupColours=grpcolor, title = "PCA plot", 
        labels = MSnset_data$Bio.Rep,labelsize=2, legend=TRUE)

## ----coverageplot,fig.width=6,fig.height=5,out.width='.85\\textwidth', fig.cap="Protein sequence coverage plot", message=FALSE,cache=TRUE,fig.asp=0.7----
mySequenceFile <- system.file('extdata', "P03372.fasta", package="qPLEXanalyzer")
coveragePlot(MSnset_data, ProteinID="P03372", name="ESR1", fastaFile=mySequenceFile)

## ----norm, message=FALSE,cache=TRUE-----------------------------------
MSnset_data <- MSnset_data[,-c(5)]
MSnset_norm <- normalizeQuantiles(MSnset_data)
MSnset_norm <- normalizeScaling(MSnset_data,func=median)
MSnset_norm <- groupScaling(MSnset_data,func=median, Grp="Grp")

## ----summarize,fig.width=6,fig.height=5,out.width='.85\\textwidth',message=FALSE,cache=TRUE----
MSnset_Pnorm <- summarizeIntensities(MSnset_norm, sum, human_anno)

## ----regress,fig.width=6,fig.height=5,out.width='.85\\textwidth', fig.cap="Correlation between bait protein and enriched proteins before and after regression", message=FALSE,cache=TRUE,fig.asp=0.7----
data(exp3_OHT_ESR1)
MSnset_reg <- convertToMSnset(exp3_OHT_ESR1$intensities_qPLEX1,
                               metadata=exp3_OHT_ESR1$metadata_qPLEX1,
                               indExpData=c(7:16),indFData=c(1:6),
                               rmMissing=TRUE)
MSnset_P <- summarizeIntensities(MSnset_reg, sum, human_anno)
MSnset_P <- rowscaling(MSnset_P,mean)
IgG_ind <- which(pData(MSnset_P)$Label == "IgG")
Reg_data <- regressIntensity(MSnset_P, controlInd=IgG_ind, ProteinId="P03372")

## ----diffexp_regress,fig.width=6,fig.height=5,out.width='.85\\textwidth', fig.cap="MA plot", message=FALSE,cache=TRUE,fig.asp=0.7----
contrasts <- c(DSG.FA_vs_FA = "DSG.FA - FA")
diffstats <- computeDiffStats(data=MSnset_Pnorm, contrasts=contrasts, 
                              applyLog2Transform = TRUE)
diffexp <- getContrastResults(diffstats=diffstats, contrast=contrasts, 
                              controlGroup = "IgG", ann= human_anno)
print(maPlot(diffexp, significanceLevel = 0.0025, minLogFoldChangeForLabelling = 3,
             title=names(contrasts)))

## ----volcano_regress,fig.width=6,fig.height=5,out.width='.85\\textwidth', fig.cap="Volcano plot", message=FALSE,cache=TRUE,fig.asp=0.7----
with(diffexp, plot(logFC, -log10(adj.P.Val), pch=20, main="Volcano plot",
                   xlab="log2FC"))
with(subset(diffexp, adj.P.Val<.01 ), points(logFC, -log10(adj.P.Val), pch=20, col="red"))
with(subset(diffexp, adj.P.Val< 0.0025), text(logFC, -log10(adj.P.Val), 
                                           labels=Gene_Symbol, cex= 0.7, pos=2))

